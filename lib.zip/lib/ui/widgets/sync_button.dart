// import 'package:flutter/material.dart';

// class SyncButton extends StatelessWidget {
//   Color backgroundColor,
//   Image,
//   const SyncButton({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//                     decoration: BoxDecoration(
//                       color: white,
//                       borderRadius: BorderRadius.circular(20)
//                     ),
//                      child: Column(children: [
//                       Image.asset("assets/icons/item.png",height: 90,width: 70,),
//                       Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Text("SKU", style: TextStyle(color: mainColor),),
//                       )
                
//                      ]) ,
//                   );
//   }
// }